# Decision Benchmark v2 report

Saved observations only; fixtures are not model quality evidence.

## contract / raw_text / a404508168c4 / hardware_unspecified / region_unspecified / in_process

| Model | Status | Valid/eligible | Accuracy | Operational | p95 ms | Goodput |
|---|---|---:|---:|---:|---:|---:|
| uniform · closed_loop B1/C2 · 790d41b2 | completed | 18/18 | 0.4444 | 0.4444 | 0.06202 | 1.046e+04 |
| uniform-control · closed_loop B1/C2 · 8fc76095 | completed | 18/18 | 0.4444 | 0.4444 | 0.05583 | 7055 |
| uniform · fixed B1/C2 · 64abe64f | completed | 18/18 | 0.4444 | 0.4444 | 0.3275 | 875 |
| uniform-control · fixed B1/C2 · c11fb53e | completed | 18/18 | 0.4444 | 0.4444 | 0.247 | 877.9 |
| uniform · poisson B1/C2 · 45487a3e | completed | 18/18 | 0.4444 | 0.4444 | 0.2928 | 998.2 |
| uniform-control · poisson B1/C2 · ba7eafc3 | completed | 18/18 | 0.4444 | 0.4444 | 0.2169 | 999.4 |

Descriptive frontier: uniform-control · closed_loop B1/C2 · 8fc76095. No significance claim; verify common eligibility and hardware before comparison.

### Paired source-group intervals

```json
[
  {
    "left_experiment_id": "790d41b2f5fb692610da02aee03941ca88999832a33535f7a46808d2d331a513",
    "right_experiment_id": "8fc76095a60461b70efd4bb94364be437940f1d3dc90564f49cc74dbc381f4ef",
    "direction": "right_minus_left",
    "left_decisions": 18,
    "right_decisions": 18,
    "common_decisions": 18,
    "left_only": 0,
    "right_only": 0,
    "population": {
      "decisions": 18,
      "groups": 5,
      "identity_sha256": "c23182a1e68b68fa4c71528dc0108cfc61ff0e08336869625c57fff125956bfa",
      "jointly_eligible_decisions": 18,
      "jointly_eligible_groups": 5,
      "jointly_eligible_identity_sha256": "c23182a1e68b68fa4c71528dc0108cfc61ff0e08336869625c57fff125956bfa",
      "eligibility_mismatches": 0,
      "left_only": 0,
      "right_only": 0,
      "left_not_run": 0,
      "right_not_run": 0
    },
    "conditional_accuracy_delta": {
      "estimate": 0.0,
      "groups": 5,
      "observations": 18,
      "confidence": 0.95,
      "seed": 0,
      "resamples": 2000,
      "interval": [
        0.0,
        0.0
      ],
      "status": "estimated"
    },
    "operational_accuracy_delta": {
      "estimate": 0.0,
      "groups": 5,
      "observations": 18,
      "confidence": 0.95,
      "seed": 0,
      "resamples": 2000,
      "interval": [
        0.0,
        0.0
      ],
      "status": "estimated"
    },
    "left_valid": 18,
    "right_valid": 18,
    "multiple_comparisons_adjusted": false
  },
  {
    "left_experiment_id": "790d41b2f5fb692610da02aee03941ca88999832a33535f7a46808d2d331a513",
    "right_experiment_id": "64abe64f5b86ac05cb39b563a7c1f818748076e24a51a8ca0d5bea74dfad4f02",
    "direction": "right_minus_left",
    "left_decisions": 18,
    "right_decisions": 18,
    "common_decisions": 18,
    "left_only": 0,
    "right_only": 0,
    "population": {
      "decisions": 18,
      "groups": 5,
      "identity_sha256": "c23182a1e68b68fa4c71528dc0108cfc61ff0e08336869625c57fff125956bfa",
      "jointly_eligible_decisions": 18,
      "jointly_eligible_groups": 5,
      "jointly_eligible_identity_sha256": "c23182a1e68b68fa4c71528dc0108cfc61ff0e08336869625c57fff125956bfa",
      "eligibility_mismatches": 0,
      "left_only": 0,
      "right_only": 0,
      "left_not_run": 0,
      "right_not_run": 0
    },
    "conditional_accuracy_delta": {
      "estimate": 0.0,
      "groups": 5,
      "observations": 18,
      "confidence": 0.95,
      "seed": 0,
      "resamples": 2000,
      "interval": [
        0.0,
        0.0
      ],
      "status": "estimated"
    },
    "operational_accuracy_delta": {
      "estimate": 0.0,
      "groups": 5,
      "observations": 18,
      "confidence": 0.95,
      "seed": 0,
      "resamples": 2000,
      "interval": [
        0.0,
        0.0
      ],
      "status": "estimated"
    },
    "left_valid": 18,
    "right_valid": 18,
    "multiple_comparisons_adjusted": false
  },
  {
    "left_experiment_id": "790d41b2f5fb692610da02aee03941ca88999832a33535f7a46808d2d331a513",
    "right_experiment_id": "c11fb53ee8327f09bf99cf63d1e05c5c142c3f49fa0721814ae7e47e9c185578",
    "direction": "right_minus_left",
    "left_decisions": 18,
    "right_decisions": 18,
    "common_decisions": 18,
    "left_only": 0,
    "right_only": 0,
    "population": {
      "decisions": 18,
      "groups": 5,
      "identity_sha256": "c23182a1e68b68fa4c71528dc0108cfc61ff0e08336869625c57fff125956bfa",
      "jointly_eligible_decisions": 18,
      "jointly_eligible_groups": 5,
      "jointly_eligible_identity_sha256": "c23182a1e68b68fa4c71528dc0108cfc61ff0e08336869625c57fff125956bfa",
      "eligibility_mismatches": 0,
      "left_only": 0,
      "right_only": 0,
      "left_not_run": 0,
      "right_not_run": 0
    },
    "conditional_accuracy_delta": {
      "estimate": 0.0,
      "groups": 5,
      "observations": 18,
      "confidence": 0.95,
      "seed": 0,
      "resamples": 2000,
      "interval": [
        0.0,
        0.0
      ],
      "status": "estimated"
    },
    "operational_accuracy_delta": {
      "estimate": 0.0,
      "groups": 5,
      "observations": 18,
      "confidence": 0.95,
      "seed": 0,
      "resamples": 2000,
      "interval": [
        0.0,
        0.0
      ],
      "status": "estimated"
    },
    "left_valid": 18,
    "right_valid": 18,
    "multiple_comparisons_adjusted": false
  },
  {
    "left_experiment_id": "790d41b2f5fb692610da02aee03941ca88999832a33535f7a46808d2d331a513",
    "right_experiment_id": "45487a3ec1b6d61c9f3eb99ca01117025f801f02b9f4d7e34ec04ee054ad58da",
    "direction": "right_minus_left",
    "left_decisions": 18,
    "right_decisions": 18,
    "common_decisions": 18,
    "left_only": 0,
    "right_only": 0,
    "population": {
      "decisions": 18,
      "groups": 5,
      "identity_sha256": "c23182a1e68b68fa4c71528dc0108cfc61ff0e08336869625c57fff125956bfa",
      "jointly_eligible_decisions": 18,
      "jointly_eligible_groups": 5,
      "jointly_eligible_identity_sha256": "c23182a1e68b68fa4c71528dc0108cfc61ff0e08336869625c57fff125956bfa",
      "eligibility_mismatches": 0,
      "left_only": 0,
      "right_only": 0,
      "left_not_run": 0,
      "right_not_run": 0
    },
    "conditional_accuracy_delta": {
      "estimate": 0.0,
      "groups": 5,
      "observations": 18,
      "confidence": 0.95,
      "seed": 0,
      "resamples": 2000,
      "interval": [
        0.0,
        0.0
      ],
      "status": "estimated"
    },
    "operational_accuracy_delta": {
      "estimate": 0.0,
      "groups": 5,
      "observations": 18,
      "confidence": 0.95,
      "seed": 0,
      "resamples": 2000,
      "interval": [
        0.0,
        0.0
      ],
      "status": "estimated"
    },
    "left_valid": 18,
    "right_valid": 18,
    "multiple_comparisons_adjusted": false
  },
  {
    "left_experiment_id": "790d41b2f5fb692610da02aee03941ca88999832a33535f7a46808d2d331a513",
    "right_experiment_id": "ba7eafc3ff4af2547f76287aa7058c2e3ef4d640c8d3e978f63f41cccfe01de7",
    "direction": "right_minus_left",
    "left_decisions": 18,
    "right_decisions": 18,
    "common_decisions": 18,
    "left_only": 0,
    "right_only": 0,
    "population": {
      "decisions": 18,
      "groups": 5,
      "identity_sha256": "c23182a1e68b68fa4c71528dc0108cfc61ff0e08336869625c57fff125956bfa",
      "jointly_eligible_decisions": 18,
      "jointly_eligible_groups": 5,
      "jointly_eligible_identity_sha256": "c23182a1e68b68fa4c71528dc0108cfc61ff0e08336869625c57fff125956bfa",
      "eligibility_mismatches": 0,
      "left_only": 0,
      "right_only": 0,
      "left_not_run": 0,
      "right_not_run": 0
    },
    "conditional_accuracy_delta": {
      "estimate": 0.0,
      "groups": 5,
      "observations": 18,
      "confidence": 0.95,
      "seed": 0,
      "resamples": 2000,
      "interval": [
        0.0,
        0.0
      ],
      "status": "estimated"
    },
    "operational_accuracy_delta": {
      "estimate": 0.0,
      "groups": 5,
      "observations": 18,
      "confidence": 0.95,
      "seed": 0,
      "resamples": 2000,
      "interval": [
        0.0,
        0.0
      ],
      "status": "estimated"
    },
    "left_valid": 18,
    "right_valid": 18,
    "multiple_comparisons_adjusted": false
  }
]
```

## Closed-loop replay

```json
{
  "manifest": {
    "schema_version": 2,
    "kind": "workflow_replay",
    "status": "completed",
    "models": [
      {
        "id": "uniform",
        "adapter": "uniform",
        "enabled": false,
        "model_id": null,
        "revision": null,
        "processor_revision": null,
        "precision": "float64",
        "quantization": "none",
        "execution_mode": "sequential",
        "calibration": "none",
        "calibration_sha256": null,
        "calibration_file": null,
        "base_calibration": null,
        "runtime": "reference",
        "readout": "candidate",
        "protocol": "compatible",
        "preprocessing": "none",
        "preprocessor_endpoint_env": null,
        "preprocessor_token_env": null,
        "preprocessor_revision": null,
        "artifact_file": null,
        "artifact_sha256": null,
        "decision_adapter_path": null,
        "decision_adapter_sha256": null,
        "device": null,
        "subfolder": null,
        "context_limit": 16384,
        "http_timeout_seconds": 120.0,
        "hardware_label": null,
        "service_region": null,
        "endpoint_env": null,
        "token_env": null,
        "cost_per_request_usd": 0.0,
        "capabilities": {
          "modalities": [
            "text",
            "image",
            "audio"
          ],
          "primitives": [
            "choice",
            "noul",
            "score"
          ],
          "max_options": 52,
          "max_questions": 64,
          "probabilities": "complete",
          "batch": "none",
          "concurrent_requests": true,
          "independent_questions": true
        },
        "notes": "Sanity baseline only; passing smoke is not evidence of model quality."
      },
      {
        "id": "uniform",
        "adapter": "uniform",
        "enabled": false,
        "model_id": null,
        "revision": null,
        "processor_revision": null,
        "precision": "float64",
        "quantization": "none",
        "execution_mode": "sequential",
        "calibration": "none",
        "calibration_sha256": null,
        "calibration_file": null,
        "base_calibration": null,
        "runtime": "reference",
        "readout": "candidate",
        "protocol": "compatible",
        "preprocessing": "none",
        "preprocessor_endpoint_env": null,
        "preprocessor_token_env": null,
        "preprocessor_revision": null,
        "artifact_file": null,
        "artifact_sha256": null,
        "decision_adapter_path": null,
        "decision_adapter_sha256": null,
        "device": null,
        "subfolder": null,
        "context_limit": 16384,
        "http_timeout_seconds": 120.0,
        "hardware_label": null,
        "service_region": null,
        "endpoint_env": null,
        "token_env": null,
        "cost_per_request_usd": 0.0,
        "capabilities": {
          "modalities": [
            "text",
            "image",
            "audio"
          ],
          "primitives": [
            "choice",
            "noul",
            "score"
          ],
          "max_options": 52,
          "max_questions": 64,
          "probabilities": "complete",
          "batch": "none",
          "concurrent_requests": true,
          "independent_questions": true
        },
        "notes": "Sanity baseline only; passing smoke is not evidence of model quality."
      }
    ],
    "service": {
      "uniform": {}
    },
    "runtime": {
      "source_sha256": "faad9929d3cc663366d510e308c33c144c088d2dcf607d7b85d78084eb73384d",
      "lock_sha256": "bfbfebeb9b998fcfa79ff64116feefc417f581ad478d6199626766026537af18",
      "python": "3.12.14",
      "platform": "Linux-6.18.55-x86_64-with-glibc2.41",
      "packages": {
        "pydantic": "2.13.5",
        "numpy": "2.5.3",
        "httpx": "0.28.1",
        "torch": null,
        "transformers": null,
        "accelerate": null,
        "laya": null,
        "peft": null,
        "scikit-learn": null,
        "sentence-transformers": null,
        "setfit": null,
        "datasets": null
      }
    },
    "source_sha256": "340ac700ef682c251ba6a066451cedb196ad3e3343d8fa4890a51257e84f7f11",
    "threshold": 0.8,
    "reserved_calls": 120,
    "reserved_cost_usd": 0,
    "reasons": [],
    "execution": {
      "uniform": {
        "status": "completed",
        "reasons": [],
        "telemetry": {
          "revision": null,
          "device": null,
          "precision": "float64",
          "temperature": null,
          "calibration_temperature": null,
          "context_limit": null,
          "context_policy": "not_applicable",
          "quantization": "none",
          "quantization_details": null,
          "runtime_package": null,
          "source_revision": null,
          "base_model_id": null,
          "base_revision": null,
          "checkpoint_task": null,
          "compute_precision": null,
          "compute_backend": null,
          "runtime_options": null,
          "temperatures_by_type": null
        },
        "setup_ms": 0.030726999966645963
      }
    },
    "provider_cache_policy": "unknown",
    "result_cache": false,
    "cost_policy": "reported provider costs when available; otherwise explicit ceilings; replay tool costs"
  },
  "summary": {
    "always_small": {
      "episodes": 6,
      "successful_episodes": 0,
      "completion_rate": 0.0,
      "false_completions": 6,
      "fallback_episode_rate": 0.0,
      "retry_steps": 0,
      "p95_task_latency_ms": 0.07094249997408042,
      "ceiling_cost_per_success_usd": null,
      "reported_cost_per_success_usd": null,
      "reported_cost_episodes": 0
    },
    "always_strong": {
      "episodes": 6,
      "successful_episodes": 0,
      "completion_rate": 0.0,
      "false_completions": 6,
      "fallback_episode_rate": 0.0,
      "retry_steps": 0,
      "p95_task_latency_ms": 0.02490549999834002,
      "ceiling_cost_per_success_usd": null,
      "reported_cost_per_success_usd": null,
      "reported_cost_episodes": 0
    },
    "cascade": {
      "episodes": 6,
      "successful_episodes": 0,
      "completion_rate": 0.0,
      "false_completions": 6,
      "fallback_episode_rate": 1.0,
      "retry_steps": 0,
      "p95_task_latency_ms": 0.051695749959890236,
      "ceiling_cost_per_success_usd": null,
      "reported_cost_per_success_usd": null,
      "reported_cost_episodes": 0
    },
    "rules_first": {
      "episodes": 6,
      "successful_episodes": 6,
      "completion_rate": 1.0,
      "false_completions": 0,
      "fallback_episode_rate": 0.0,
      "retry_steps": 6,
      "p95_task_latency_ms": 0.004371499926492106,
      "ceiling_cost_per_success_usd": 0.0,
      "reported_cost_per_success_usd": 0.0,
      "reported_cost_episodes": 6
    }
  },
  "paired_comparison": {
    "baseline": "always_strong",
    "comparisons": {
      "always_small": {
        "completion_delta": {
          "estimate": 0.0,
          "groups": 2,
          "observations": 6,
          "confidence": 0.95,
          "seed": 0,
          "resamples": 2000,
          "interval": [
            0.0,
            0.0
          ],
          "status": "estimated"
        },
        "ceiling_episode_cost_delta": {
          "estimate": 0.0,
          "groups": 2,
          "observations": 6,
          "confidence": 0.95,
          "seed": 0,
          "resamples": 2000,
          "interval": [
            0.0,
            0.0
          ],
          "status": "estimated"
        }
      },
      "cascade": {
        "completion_delta": {
          "estimate": 0.0,
          "groups": 2,
          "observations": 6,
          "confidence": 0.95,
          "seed": 0,
          "resamples": 2000,
          "interval": [
            0.0,
            0.0
          ],
          "status": "estimated"
        },
        "ceiling_episode_cost_delta": {
          "estimate": 0.0,
          "groups": 2,
          "observations": 6,
          "confidence": 0.95,
          "seed": 0,
          "resamples": 2000,
          "interval": [
            0.0,
            0.0
          ],
          "status": "estimated"
        }
      },
      "rules_first": {
        "completion_delta": {
          "estimate": 1.0,
          "groups": 2,
          "observations": 6,
          "confidence": 0.95,
          "seed": 0,
          "resamples": 2000,
          "interval": [
            1.0,
            1.0
          ],
          "status": "estimated"
        },
        "ceiling_episode_cost_delta": {
          "estimate": 0.0,
          "groups": 2,
          "observations": 6,
          "confidence": 0.95,
          "seed": 0,
          "resamples": 2000,
          "interval": [
            0.0,
            0.0
          ],
          "status": "estimated"
        }
      }
    }
  }
}
```
