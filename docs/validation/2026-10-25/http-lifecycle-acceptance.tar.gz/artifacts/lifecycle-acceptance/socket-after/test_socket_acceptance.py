"""Synthetic decoder, actual API/adapters/Uvicorn and loopback TCP lifecycle checks.

The NumPy fixture and torch inference_mode shim come from the existing tests.
No model weights, GPU, paid endpoint, browser or genuine-model qualification.
"""

import asyncio
import copy
import json
import socket
import struct
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path
from types import SimpleNamespace

import httpx
import pytest
import uvicorn
from test_jev_generated import backend, payload  # existing synthetic fixture

from s1 import jev_generated
from s1.api import create_app
from s1.errors import BackendTimeoutError, BackendTransportError


class Log:
    def __init__(self, directory):
        self.events = []
        self.cv = threading.Condition()
        self.path = directory / "events.jsonl"

    def __call__(self, event):
        with self.cv:
            self.events.append(copy.deepcopy(event))
            with self.path.open("a") as stream:
                stream.write(json.dumps(event, ensure_ascii=False, allow_nan=False) + "\n")
            self.cv.notify_all()

    def count(self, name):
        with self.cv:
            return sum(row["event"] == name for row in self.events)

    def wait(self, name, count=1):
        with self.cv:
            assert self.cv.wait_for(lambda: self.count(name) >= count, timeout=5), name

    def snapshot(self):
        with self.cv:
            return copy.deepcopy(self.events)


@contextmanager
def live(backend, directory):
    log = Log(directory)
    app = create_app(
        backend,
        jev_compatible=True,
        jev_generated_actions=True,
        model_identity="experiment",
        request_evidence_sink=log,
    )
    listener = socket.socket()
    listener.bind(("127.0.0.1", 0))
    listener.listen(128)
    port = listener.getsockname()[1]
    server = uvicorn.Server(uvicorn.Config(
        app, loop="asyncio", http="h11", lifespan="off", log_level="error",
        timeout_graceful_shutdown=3,
    ))
    thread = threading.Thread(target=server.run, kwargs={"sockets": [listener]}, daemon=False)
    thread.start()
    try:
        end = time.monotonic() + 5
        while not server.started and thread.is_alive() and time.monotonic() < end:
            threading.Event().wait(0.01)
        assert server.started, "actual Uvicorn listener did not start"
        with httpx.Client(base_url=f"http://127.0.0.1:{port}", timeout=5, trust_env=False) as client:
            assert client.get("/healthz").status_code == 200
            yield client, log, port
    finally:
        server.should_exit = True
        thread.join(5)
        listener.close()
        assert not thread.is_alive(), "owned server thread leaked"
        assert not server.server_state.tasks, "owned ASGI tasks leaked"
        assert not server.server_state.connections, "owned connections leaked"
        assert not backend.model.hooks, "generated-action forward hook leaked"
        (directory / "cleanup.json").write_text(json.dumps({
            "synthetic_decoder": True,
            "real_uvicorn_socket": True,
            "server_thread_alive": thread.is_alive(),
            "pending_asgi_tasks": len(server.server_state.tasks),
            "pending_connections": len(server.server_state.connections),
            "forward_hooks": len(backend.model.hooks),
        }, indent=2) + "\n")


class ControlledGenerate:
    def __init__(self, backend):
        self.original = backend.model.lm.generate
        self.entered, self.release = threading.Event(), threading.Event()
        self.lock = threading.Lock()
        self.enter_count = self.active = self.max_active = 0
        backend.model.lm.generate = self

    def __call__(self, **kwargs):
        with self.lock:
            self.enter_count += 1
            first = self.enter_count == 1
            self.active += 1
            self.max_active = max(self.max_active, self.active)
        try:
            if first:
                self.entered.set()
                assert self.release.wait(5), "controlled synthetic decoder not released"
            return self.original(**kwargs)
        finally:
            with self.lock:
                self.active -= 1


def recover(client, backend, payload):
    response = client.post("/v1/systemone", json=payload)
    assert response.status_code == 200, response.text
    assert response.json()["answers"]["operation"]["choice"] == "CLICK"
    assert not backend.model.hooks
    assert backend.native_calls == [], "classifier path must remain unused"
    return response


def assert_terminal_pairs(log, terminals):
    rows = log.snapshot()
    starts = [row for row in rows if row["event"] == "request_started"]
    assert len(starts) == len(terminals)
    assert len({row["request_id"] for row in starts}) == len(starts)
    for start, name in zip(starts, terminals):
        request_rows = [row for row in rows if row["request_id"] == start["request_id"]]
        assert request_rows[-1]["event"] == name
        assert [row["sequence"] for row in request_rows] == list(range(len(request_rows)))
        assert sum(row["event"] in {"server_returned", "server_failed"} for row in request_rows) == 1


def test_real_socket_async_client_cancel_keeps_worker_and_cleans_then_recovers(backend, payload, tmp_path):
    control = ControlledGenerate(backend)
    with live(backend, tmp_path) as (client, log, port):
        async def scenario():
            async with httpx.AsyncClient(base_url=f"http://127.0.0.1:{port}", trust_env=False) as caller:
                task = asyncio.create_task(caller.post("/v1/systemone", json=payload))
                try:
                    assert await asyncio.to_thread(control.entered.wait, 5)
                    assert len(backend.model.hooks) == 1
                    task.cancel()
                    with pytest.raises(asyncio.CancelledError):
                        await task
                    assert not log.count("server_returned")
                    assert control.active == 1, "caller cancellation cannot hard-cancel synchronous decoder"
                finally:
                    control.release.set()
                    await asyncio.gather(task, return_exceptions=True)
        asyncio.run(scenario())
        log.wait("server_returned")
        recover(client, backend, payload)
        assert control.enter_count == 2 and control.max_active == 1
        assert_terminal_pairs(log, ["server_returned", "server_returned"])


def test_real_socket_http_read_timeout_keeps_late_return_and_recovers(backend, payload, tmp_path):
    control = ControlledGenerate(backend)
    with live(backend, tmp_path) as (client, log, port):
        try:
            with ThreadPoolExecutor(max_workers=1) as pool:
                future = pool.submit(client.post, "/v1/systemone", json=payload, timeout=0.1)
                assert control.entered.wait(5)
                with pytest.raises(httpx.ReadTimeout):
                    future.result(5)
                assert control.active == 1 and len(backend.model.hooks) == 1
                assert not log.count("server_returned")
        finally:
            control.release.set()
        log.wait("server_returned")
        recover(client, backend, payload)
        assert_terminal_pairs(log, ["server_returned", "server_returned"])


def test_real_socket_client_rst_retains_computation_not_delivery_and_recovers(backend, payload, tmp_path):
    control = ControlledGenerate(backend)
    with live(backend, tmp_path) as (client, log, port):
        raw = socket.create_connection(("127.0.0.1", port), timeout=5)
        try:
            body = json.dumps(payload).encode()
            raw.sendall((f"POST /v1/systemone HTTP/1.1\r\nHost: 127.0.0.1\r\nContent-Type: application/json\r\nContent-Length: {len(body)}\r\n\r\n").encode() + body)
            assert control.entered.wait(5)
            raw.setsockopt(socket.SOL_SOCKET, socket.SO_LINGER, struct.pack("ii", 1, 0))
            raw.close()
            assert control.active == 1 and len(backend.model.hooks) == 1
            assert not log.count("server_returned")
        finally:
            raw.close()
            control.release.set()
        log.wait("server_returned")
        recover(client, backend, payload)
        assert_terminal_pairs(log, ["server_returned", "server_returned"])


def test_real_socket_identical_queued_requests_get_distinct_ids_and_serial_decode(backend, payload, tmp_path):
    control = ControlledGenerate(backend)
    with live(backend, tmp_path) as (client, log, port):
        with ThreadPoolExecutor(max_workers=2) as pool:
            first = pool.submit(client.post, "/v1/systemone", json=payload)
            try:
                assert control.entered.wait(5)
                second = pool.submit(client.post, "/v1/systemone", json=copy.deepcopy(payload))
                log.wait("request_started", 2)
                starts = [row for row in log.snapshot() if row["event"] == "request_started"]
                assert len({row["request_id"] for row in starts}) == 2
                assert len({row["data"]["original_request_sha256"] for row in starts}) == 1
                assert log.count("inference_lock_acquired") == 1
                assert control.enter_count == 1 and not second.done()
            finally:
                control.release.set()
            assert first.result(5).status_code == second.result(5).status_code == 200
        assert control.enter_count == 2 and control.max_active == 1
        assert_terminal_pairs(log, ["server_returned", "server_returned"])


@pytest.mark.parametrize("failure,status", [(BackendTransportError, 502), (BackendTimeoutError, 504), (RuntimeError, 502)])
def test_real_socket_partial_generation_error_removes_hooks_and_recovers(backend, payload, tmp_path, failure, status):
    backend.model.fail_after = 3
    backend.model.interruption = failure
    with live(backend, tmp_path) as (client, log, port):
        response = client.post("/v1/systemone", json=payload)
        assert response.status_code == status, response.text
        failed = next(row for row in log.snapshot() if row["event"] == "server_failed")
        generation = failed["data"]["generation"]
        assert generation["raw_output"] and backend.model.generated.startswith(generation["raw_output"])
        assert generation["usage"]["output_tokens"] == len(generation["raw_token_ids"]) == 3
        assert generation["output_tokens_scope"] == "observed_emitted_before_failure"
        assert generation["forward_calls"] == 3
        assert not backend.model.hooks
        backend.model.fail_after = None
        recover(client, backend, payload)
        assert_terminal_pairs(log, ["server_failed", "server_returned"])


def test_real_socket_late_cooperative_timeout_retains_full_decode_and_recovers(backend, payload, tmp_path, monkeypatch):
    clock = [0.0]
    monkeypatch.setattr(jev_generated, "time", SimpleNamespace(monotonic=lambda: clock[0], perf_counter=time.perf_counter))
    backend.model.after_generate = lambda: clock.__setitem__(0, 21.0)
    with live(backend, tmp_path) as (client, log, port):
        response = client.post("/v1/systemone", json=payload)
        assert response.status_code == 504, response.text
        generation = next(row for row in log.snapshot() if row["event"] == "server_failed")["data"]["generation"]
        assert generation["raw_output"] == backend.model.generated
        assert generation["elapsed_ms"] == 21000
        assert generation["timeout_policy"] == "cooperative_before_after_blocking_generate_no_hard_cancel"
        assert "decoded_action" not in generation
        assert not backend.model.hooks
        backend.model.after_generate = None
        clock[0] = 0.0
        recover(client, backend, payload)
        assert_terminal_pairs(log, ["server_failed", "server_returned"])
