"""Actual default-clock20s ingress timeout; synthetic descriptor, no decoder.

No clock, timeout, middleware, request/body or model function is patched. Existing
fixture FakeLM.generate fails if called, so this is never model qualification.
"""

import hashlib
import importlib.metadata
import json
import platform
import socket
import subprocess
import threading
import time
from pathlib import Path
from types import SimpleNamespace

import jev_native_v2_browser as driver
import test_jev_native_v2_browser as fixtures
import uvicorn
from s1.browser_server_evidence import ServerEvidenceJournal

ROOT = Path(__file__).resolve().parent
journal = ServerEvidenceJournal(ROOT / "server")
model = fixtures.model_fixture()
driver.CurrentNF4HelperGuard(model)
gate_checks = []
application = driver.make_application(
    model,
    None,
    journal,
    SimpleNamespace(check=gate_checks.append),
    ROOT,
    "synthetic-test-token",
    "raw-json-v1",
    "synthetic system; never decoded",
)
listener = socket.socket()
listener.bind(("127.0.0.1", 0))
listener.listen(128)
address = listener.getsockname()
server = uvicorn.Server(uvicorn.Config(
    application, loop="asyncio", http="h11", lifespan="off", log_level="error",
    timeout_graceful_shutdown=3,
))
thread = threading.Thread(target=server.run, kwargs={"sockets": [listener]}, daemon=False)
thread.start()
started_wait = time.monotonic()
while not server.started and thread.is_alive() and time.monotonic() - started_wait < 5:
    threading.Event().wait(0.01)
assert server.started, "owned Uvicorn listener did not start"
partial = health = None
result = {}


def receive_all(connection):
    data = b""
    while True:
        block = connection.recv(65536)
        if not block:
            break
        data += block
    return data


try:
    partial = socket.create_connection(address, timeout=30)
    started = time.monotonic()
    partial.sendall(
        b"POST /v1/systemone HTTP/1.1\r\nHost: localhost\r\n"
        b"Content-Length: 100\r\nContent-Type: application/json\r\n"
        b"Authorization: Bearer synthetic-test-token\r\nConnection: close\r\n\r\n{"
    )
    # Leave the client socket open; no more bytes and no client close/reset.
    reply = receive_all(partial)
    elapsed = time.monotonic() - started
    (ROOT / "partial-response.http").write_bytes(reply)
    assert reply.startswith(b"HTTP/1.1 504"), reply
    assert 19.5 <= elapsed < 25, elapsed
    headers, body = reply.split(b"\r\n\r\n", 1)
    refusal = json.loads(body)
    assert refusal["detail"]["type"] == "TimeoutError", refusal
    assert "while receiving body" in refusal["detail"]["message"], refusal
    assert "answers" not in refusal
    health = socket.create_connection(address, timeout=5)
    health_started = time.monotonic()
    health.sendall(b"GET /healthz HTTP/1.1\r\nHost: localhost\r\nConnection: close\r\n\r\n")
    healthy = receive_all(health)
    health_elapsed = time.monotonic() - health_started
    (ROOT / "health-response.http").write_bytes(healthy)
    assert healthy.startswith(b"HTTP/1.1 200"), healthy
    record = json.loads((ROOT / "http/0000/exchange.json").read_text())
    assert record["status"] == 504 and record["request"] is None
    assert record["error"] == refusal["detail"]
    assert (ROOT / "http/0000/response.bin").read_bytes() == body
    assert not (ROOT / "http/0000/candidate-response.bin").exists()
    snapshot = journal.snapshot()
    assert snapshot["requests"] == [], snapshot
    assert not application.state.request_evidence_errors
    assert driver.TRACE.get() is None
    result = {
        "scope": "Actual native make_application/Uvicorn h11/loopback TCP; synthetic existing descriptor and gate observer, no decoder invoked; not genuine-model qualification",
        "result": "passed",
        "default_clock": True,
        "deadline_patched": False,
        "client_connection_open_until_response": True,
        "body_bytes_sent": 1,
        "declared_body_bytes": 100,
        "partial_body_status": 504,
        "partial_body_response_elapsed_seconds": elapsed,
        "recovery_status": 200,
        "recovery_elapsed_seconds": health_elapsed,
        "generation_requests": len(snapshot["requests"]),
        "gate_checks": gate_checks,
        "http_exchange": record,
    }
finally:
    if partial is not None:
        partial.close()
    if health is not None:
        health.close()
    server.should_exit = True
    thread.join(5)
    listener.close()
    assert not thread.is_alive(), "owned server thread leaked"
    assert not server.server_state.tasks, "owned ASGI tasks leaked"
    assert not server.server_state.connections, "owned server connections leaked"
    cleanup = {"server_thread_alive": thread.is_alive(), "pending_asgi_tasks": len(server.server_state.tasks), "pending_connections": len(server.server_state.connections)}
    (ROOT / "cleanup.json").write_text(json.dumps(cleanup, indent=2) + "\n")
    result["cleanup"] = cleanup
    result["run_head"] = subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip()
    result["worktree_status"] = subprocess.check_output(["git", "status", "--short"], text=True)
    result["tracked_diff_sha256"] = hashlib.sha256(subprocess.check_output(["git", "diff", "--", "scripts/jev_native_v2_browser.py"])).hexdigest()
    result["python"] = platform.python_version()
    result["dependencies"] = {name: importlib.metadata.version(name) for name in ["uvicorn", "fastapi", "starlette", "anyio", "httpx"]}
    result["source_sha256"] = {str(path): hashlib.sha256(path.read_bytes()).hexdigest() for path in [Path("scripts/jev_native_v2_browser.py"), Path("tests/test_jev_native_v2_browser.py"), Path(__file__)]}
    (ROOT / "summary.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
