"""Real loopback core API recovery; deterministic CPU backend, no model/GPU."""
import hashlib
import http.client
import importlib.metadata
import json
import platform
import socket
import subprocess
import threading
import time
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

import uvicorn

from s1.api import create_app
from s1.backends import HTTPBackend, UniformBackend
from s1.contracts import DecisionRequest
from s1.errors import BackendTimeoutError, BackendTransportError, RequestValidationError

OUTPUT = Path(__file__).resolve().parent
PAYLOAD = {
    "state": "fixed synthetic recovery input",
    "questions": {
        "route": {"type": "choice", "instructions": "Pick a fixed route", "criteria": {"left": "Left", "right": "Right"}},
        "approve": {"type": "noul", "instructions": "Approve?"},
    },
}
DecisionRequest.model_validate(PAYLOAD)


def wait(predicate, message, seconds=5):
    stop = time.monotonic() + seconds
    while not predicate() and time.monotonic() < stop:
        time.sleep(.01)
    assert predicate(), message


@contextmanager
def service(backend):
    listener = socket.socket()
    listener.bind(("127.0.0.1", 0))
    listener.listen()
    server = uvicorn.Server(uvicorn.Config(create_app(backend), log_level="critical", http="h11", timeout_graceful_shutdown=3))
    thread = threading.Thread(target=server.run, kwargs={"sockets": [listener]})
    try:
        thread.start()
        wait(lambda: server.started, "API failed to start")
        yield listener.getsockname(), server
    finally:
        server.should_exit = True
        thread.join(5)
        listener.close()
        assert not thread.is_alive(), "API thread did not stop"
        assert not server.server_state.tasks, "API tasks remain"
        assert not server.server_state.connections, "API connections remain"


def post(address, route, payload):
    client = http.client.HTTPConnection(*address, timeout=3)
    try:
        client.request("POST", route, json.dumps(payload), {"Content-Type": "application/json", "Connection": "close"})
        response = client.getresponse()
        body = response.read()
        return response.status, json.loads(body) if body.startswith(b"{") or body.startswith(b"[") else body.decode()
    finally:
        client.close()


class Scripted(UniformBackend):
    def __init__(self):
        self.next_failure = None
        self.predict_calls = self.native_batch_calls = 0

    def consume_failure(self):
        failure, self.next_failure = self.next_failure, None
        if failure == "malformed":
            return {"answers": None}
        if failure is not None:
            raise failure
        return None

    def predict(self, request):
        self.predict_calls += 1
        result = self.consume_failure()
        return result if result is not None else super().predict(request)


class NativeBatch(Scripted):
    def predict_batch(self, requests):
        self.native_batch_calls += 1
        result = self.consume_failure()
        if result is not None:
            return [result for _ in requests]
        return [UniformBackend.predict(self, request) for request in requests]


CASES = [
    ("typed_timeout", lambda: BackendTimeoutError("synthetic timeout"), 504),
    ("typed_transport", lambda: BackendTransportError("synthetic transport failure"), 502),
    ("typed_validation", lambda: RequestValidationError("synthetic invalid request"), 422),
    ("malformed_response", lambda: "malformed", 502),
    ("internal_exception", lambda: RuntimeError("synthetic internal failure"), 500),
]
results = []
for batch_mode in ("fallback", "native"):
    backend = NativeBatch() if batch_mode == "native" else Scripted()
    with service(backend) as (address, server):
        routes = ("/decide", "/v1/systemone") if batch_mode == "fallback" else ()
        routes += ("/decide/batch", "/v1/systemone/batch")
        for route in routes:
            batched = route.endswith("/batch")
            data = [PAYLOAD, PAYLOAD] if batched else PAYLOAD
            for name, make_failure, expected in CASES:
                before_predict, before_batch = backend.predict_calls, backend.native_batch_calls
                backend.next_failure = make_failure()
                status, body = post(address, route, data)
                assert status == expected, (route, name, status, body)
                if expected == 500:
                    assert "synthetic internal failure" not in str(body)
                recovery_status, recovered = post(address, route, data)
                assert recovery_status == 200, (route, name, recovery_status, recovered)
                answers = recovered if batched else [recovered]
                assert len(answers) == (2 if batched else 1)
                for answer in answers:
                    assert answer["answers"]["route"]["probabilities"] == {"left": .5, "right": .5}
                predict_delta = backend.predict_calls - before_predict
                batch_delta = backend.native_batch_calls - before_batch
                if batched and batch_mode == "native":
                    assert predict_delta == 0 and batch_delta == 2
                else:
                    expected_predicts = (4 if name == "malformed_response" else 3) if batched else 2
                    assert batch_delta == 0 and predict_delta == expected_predicts, (route, name, predict_delta)
                results.append({"route": route, "batch_mode": batch_mode if batched else None, "failure": name, "status": status, "recovery_status": recovery_status, "predict_calls": predict_delta, "native_batch_calls": batch_delta})


class OwnedUpstream(ThreadingHTTPServer):
    daemon_threads = False

    def __init__(self):
        self.guard = threading.Lock()
        self.active = set()
        self.calls = 0
        self.entered = threading.Event()
        self.release = threading.Event()
        self.first_finished = threading.Event()
        super().__init__(("127.0.0.1", 0), UpstreamHandler)


class UpstreamHandler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def setup(self):
        super().setup()
        with self.server.guard:
            self.server.active.add(self.connection)

    def finish(self):
        try:
            super().finish()
        finally:
            with self.server.guard:
                self.server.active.discard(self.connection)

    def log_message(self, *_args):
        pass

    def do_POST(self):
        with self.server.guard:
            self.server.calls += 1
            count = self.server.calls
        payload = json.loads(self.rfile.read(int(self.headers["Content-Length"])))
        if count == 1:
            self.server.entered.set()
            assert self.server.release.wait(5), "Owned first upstream request not released"
        body = json.dumps(UniformBackend().predict(DecisionRequest.model_validate(payload))).encode()
        try:
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except (BrokenPipeError, ConnectionResetError):
            self.close_connection = True
        finally:
            if count == 1:
                self.server.first_finished.set()


class ObservedHTTPBackend(HTTPBackend):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.failure_causes = []

    def _post(self, payload):
        try:
            return super()._post(payload)
        except BackendTimeoutError as exc:
            self.failure_causes.append(type(exc.__cause__).__name__)
            raise


upstream = OwnedUpstream()
upstream_thread = threading.Thread(target=upstream.serve_forever)
upstream_thread.start()
backend = ObservedHTTPBackend(f"http://127.0.0.1:{upstream.server_port}/decide", timeout=.2)
try:
    with service(backend) as (address, server):
        status, timeout_body = post(address, "/decide", PAYLOAD)
        assert upstream.entered.is_set() and status == 504, (status, timeout_body)
        assert timeout_body == {"detail": "backend request timed out"}
        assert upstream.calls == 1, "HTTPBackend retried first request"
        assert backend.failure_causes == ["ReadTimeout"], backend.failure_causes
        status, recovered = post(address, "/decide", PAYLOAD)
        assert status == 200 and upstream.calls == 2, (status, recovered, upstream.calls)
        assert recovered["answers"]["route"]["probabilities"] == {"left": .5, "right": .5}
        upstream.release.set()
        assert upstream.first_finished.wait(3)
        backend.close()
        assert backend.client.is_closed
        wait(lambda: not upstream.active, "Upstream sockets remain after HTTPBackend.close")
        upstream_result = {"timeout_status":504,"recovery_status":200,"actual_upstream_requests":upstream.calls,"no_retry":True,"client_closed":backend.client.is_closed,"actual_cause_types":backend.failure_causes,"upstream_connections_after_close":len(upstream.active)}
finally:
    backend.close()
    upstream.release.set()
    upstream.shutdown()
    upstream.server_close()
    upstream_thread.join(5)
    assert not upstream_thread.is_alive()
    assert not upstream.active

report = {
    "scope":"real uvicorn/h11 loopback services; synthetic CPU backend only; no model, GPU or external requests",
    "head":subprocess.check_output(["git","rev-parse","HEAD"],text=True).strip(),
    "python":platform.python_version(),
    "versions":{key:importlib.metadata.version(key) for key in ("fastapi","starlette","uvicorn","httpx")},
    "synthetic_payload_sha256":hashlib.sha256(json.dumps(PAYLOAD,separators=(",", ":"),sort_keys=True).encode()).hexdigest(),
    "error_recovery_scenarios":len(results),
    "api_responses_verified":len(results)*2+2,
    "results":results,
    "http_backend_actual_read_timeout":upstream_result,
    "cleanup":"All API tasks/connections/server threads and upstream handlers/listeners released; HTTPBackend client closed",
    "new_defects":[],
}
(OUTPUT / "results.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps({key:report[key] for key in ("error_recovery_scenarios","api_responses_verified","http_backend_actual_read_timeout","cleanup","new_defects")}))
