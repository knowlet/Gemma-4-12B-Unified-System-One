# Release dataset attribution

This release adapts BoolQ by Christopher Clark, Kenton Lee, Ming-Wei Chang, Tom Kwiatkowski, Michael Collins and Kristina Toutanova (2019), Google Research. BoolQ and these transformed BoolQ dataset files are CC-BY-SA-3.0: https://creativecommons.org/licenses/by-sa/3.0/

Original: https://github.com/google-research-datasets/boolean-questions

Changes: deterministic passage-group sampling, balanced labels, separate train/calibration/test splits, and conversion to the System One NOUL request schema. Original questions, passages and boolean labels are preserved.

The media regression file retains earlier MNIST (MIT) and FSDD (CC-BY-SA-4.0) samples. Authors, immutable source revisions, transformations and license links are preserved in provenance.json. It is not training data.

These are specialist English reading-comprehension data, with balanced labels rather than natural deployment prevalence. No broad reasoning, multimodal training or foundation-model pretraining-disjointness claim is made.
