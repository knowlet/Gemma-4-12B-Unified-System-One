# Breakthrough outcome audit

Status: `incomplete_or_not_run`; 8 declared profiles.

Formal acceptance is not assessed; official rank/cost are unknown, sealed evaluation is not run.

| Profile | Status | Fresh test | Public | BoolQ / native / historic | Coherence calibrated / unit |
| --- | --- | ---: | --- | --- | --- |
| released-current | not_run | 0 | ?/? | incomplete / incomplete / incomplete | incomplete / incomplete |
| released-user_question | not_run | 0 | ?/? | incomplete / incomplete / incomplete | incomplete / incomplete |
| base-current | not_run | 0 | ?/? | incomplete / incomplete / incomplete | incomplete / incomplete |
| base-user_question | not_run | 0 | ?/? | incomplete / incomplete / incomplete | incomplete / incomplete |
| released-user-control | not_run | 0 | ?/? | incomplete / incomplete / incomplete | incomplete / incomplete |
| released-user-head-init | not_run | 0 | ?/? | incomplete / incomplete / incomplete | incomplete / incomplete |
| released-user-head | not_run | 0 | ?/? | incomplete / incomplete / incomplete | incomplete / incomplete |
| released-user-lora | not_run | 0 | ?/? | incomplete / incomplete / incomplete | incomplete / incomplete |

The JSON retains per-type/template metrics, paired source-group intervals, all raw hashes, errors and unexecuted populations. Coherence outcome rows are not independent denominators. Raw-logit replay latency is CPU replay, not GPU latency. Historical Jev-Omni is reported separately.
