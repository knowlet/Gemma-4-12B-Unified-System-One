import hashlib
import json
from pathlib import Path

import torch

expected = torch.ones((2, 3331), dtype=torch.int64)
expected[0, 2243:] = 0
results = []
for method in ('combined', 'copy_then_cast'):
    device = expected.to('mps')
    if method == 'combined':
        copied = device.to(device='cpu', dtype=torch.bool)
    else:
        copied = device.to(device='cpu').bool()
    torch.mps.synchronize()
    after = device.cpu()
    results.append({'method': method, 'copy_mismatches': int((copied != expected.bool()).sum()),
                    'source_mutated_values': int((after != expected).sum()),
                    'source_unique_after': sorted(after.unique().tolist()),
                    'before_sha256': hashlib.sha256(expected.numpy().tobytes()).hexdigest(),
                    'after_sha256': hashlib.sha256(after.numpy().tobytes()).hexdigest()})
report = {'torch': torch.__version__, 'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'results': results, 'scope': 'Known int64 attention-mask alias copy, no model/inference.'}
Path(__file__).with_name('report.json').write_text(json.dumps(report, indent=2)+'\n')
print(json.dumps(report))
