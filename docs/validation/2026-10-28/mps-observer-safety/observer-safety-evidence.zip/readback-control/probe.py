import hashlib
import json
from pathlib import Path

import torch

expected = ((torch.arange(2243 * 3840, dtype=torch.int64) % 257) / 256).reshape(2243, 3840).to(torch.bfloat16)
device = expected.to('mps')
results = []
for start in (0, 68, 136, 2176):
    stop = min(start + 68, 2243)
    source = device[start:stop]
    truth = expected[start:stop].float()
    for method in ('combined', 'copy_then_cast', 'cast_then_copy'):
        if method == 'combined':
            copied = source.to(device='cpu', dtype=torch.float32)
        elif method == 'copy_then_cast':
            copied = source.to(device='cpu').float()
        else:
            copied = source.float().cpu()
        torch.mps.synchronize()
        finite = copied.isfinite()
        results.append({'start_row': start, 'source_storage_offset': source.storage_offset(),
                        'method': method, 'values': copied.numel(),
                        'nonfinite': int((~finite).sum()), 'mismatches': int((copied != truth).sum()),
                        'finite_min': float(copied[finite].min()) if finite.any() else None,
                        'finite_max': float(copied[finite].max()) if finite.any() else None})
report = {'torch': torch.__version__, 'source_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          'shape': list(device.shape), 'results': results,
          'scope': 'Known finite BF16 storage-offset view copy, no model, no inference.'}
Path(__file__).with_name('report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report))
